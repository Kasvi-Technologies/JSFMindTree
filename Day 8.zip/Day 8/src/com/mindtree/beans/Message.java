package com.mindtree.beans;


public class Message {
	
	private String message = "From Message Object";

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
