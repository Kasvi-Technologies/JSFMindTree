package com.mindtree.beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class LoopingBean {
	
	private String[] colours = {"Red", "Yellow", "Green", "Blue", "Black"};

	public String[] getColours() {
		return colours;
	}
	
	public List<Product> getProducts(){
	
		Product p = new Product(100, "sadasd",5656,56);
		Product p1 = new Product(200, "sadasd",5656,56);
		Product p2 = new Product(300, "sadasd",5656,56);
		Product p3 = new Product(400, "sadasd",5656,56);
		Product p4 = new Product(500, "sadasd",5656,56);
		
		List<Product> productList = new ArrayList<Product>();
		
		productList.add(p);
		productList.add(p1);
		productList.add(p2);
		productList.add(p3);
		productList.add(p4);
		
		return productList;
	}
	
	

}
